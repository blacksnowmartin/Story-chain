"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useSupabase } from "@/components/supabase-provider"
import { Plus, BookOpen, Trophy, MessageSquare } from "lucide-react"

type Challenge = {
  id: string
  title: string
  description: string
  created_at: string
  user_id: string
  status: string
  submission_count: number
}

type Submission = {
  id: string
  challenge_id: string
  challenge_title: string
  content: string
  created_at: string
  votes: number
  status: string
}

export default function Dashboard() {
  const { user, supabase, loading } = useSupabase()
  const router = useRouter()
  const [userProfile, setUserProfile] = useState<any>(null)
  const [myChallenges, setMyChallenges] = useState<Challenge[]>([])
  const [mySubmissions, setMySubmissions] = useState<Submission[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!loading && !user) {
      router.push("/signin")
    }
  }, [user, loading, router])

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return

      try {
        // Fetch user profile
        const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

        setUserProfile(profile)

        // For creators: fetch their challenges
        if (profile?.user_type === "creator") {
          const { data: challenges } = await supabase
            .from("challenges")
            .select("*")
            .eq("user_id", user.id)
            .order("created_at", { ascending: false })

          setMyChallenges(challenges || [])
        }

        // For contributors: fetch their submissions
        if (profile?.user_type === "contributor") {
          const { data: submissions } = await supabase
            .from("submissions")
            .select("*, challenges(title)")
            .eq("user_id", user.id)
            .order("created_at", { ascending: false })

          const formattedSubmissions =
            submissions?.map((sub: any) => ({
              ...sub,
              challenge_title: sub.challenges.title,
            })) || []

          setMySubmissions(formattedSubmissions)
        }
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [user, supabase])

  if (loading || isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 flex justify-center">
        <div className="text-center">Loading...</div>
      </div>
    )
  }

  const isCreator = userProfile?.user_type === "creator"

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, {userProfile?.name || "User"}</p>
        </div>
        {isCreator && (
          <Link href="/challenges/new">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Challenge
            </Button>
          </Link>
        )}
      </div>

      {isCreator ? (
        <Tabs defaultValue="challenges">
          <TabsList className="mb-6">
            <TabsTrigger value="challenges">My Challenges</TabsTrigger>
            <TabsTrigger value="stats">Stats</TabsTrigger>
          </TabsList>
          <TabsContent value="challenges">
            {myChallenges.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {myChallenges.map((challenge) => (
                  <Card key={challenge.id}>
                    <CardHeader>
                      <CardTitle>{challenge.title}</CardTitle>
                      <CardDescription>
                        Created on {new Date(challenge.created_at).toLocaleDateString()}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="line-clamp-3">{challenge.description}</p>
                      <div className="flex items-center mt-4 text-sm text-muted-foreground">
                        <MessageSquare className="mr-1 h-4 w-4" />
                        <span>{challenge.submission_count || 0} submissions</span>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Link href={`/challenges/${challenge.id}`} className="w-full">
                        <Button variant="outline" className="w-full">
                          View Challenge
                        </Button>
                      </Link>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <BookOpen className="mx-auto h-12 w-12 text-muted-foreground" />
                <h3 className="mt-4 text-lg font-medium">No challenges yet</h3>
                <p className="mt-2 text-muted-foreground">
                  Create your first challenge to start collecting creative ideas.
                </p>
                <Link href="/challenges/new" className="mt-4 inline-block">
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Create Challenge
                  </Button>
                </Link>
              </div>
            )}
          </TabsContent>
          <TabsContent value="stats">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Total Challenges</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold">{myChallenges.length}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Total Submissions</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold">
                    {myChallenges.reduce((acc, challenge) => acc + (challenge.submission_count || 0), 0)}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Selected Winners</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold">{myChallenges.filter((c) => c.status === "completed").length}</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      ) : (
        <Tabs defaultValue="submissions">
          <TabsList className="mb-6">
            <TabsTrigger value="submissions">My Submissions</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>
          <TabsContent value="submissions">
            {mySubmissions.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {mySubmissions.map((submission) => (
                  <Card key={submission.id}>
                    <CardHeader>
                      <CardTitle className="line-clamp-1">{submission.challenge_title}</CardTitle>
                      <CardDescription>
                        Submitted on {new Date(submission.created_at).toLocaleDateString()}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="line-clamp-3">{submission.content}</p>
                      <div className="flex items-center mt-4 text-sm">
                        <div className="flex items-center text-muted-foreground">
                          <Trophy className="mr-1 h-4 w-4" />
                          <span>{submission.votes || 0} votes</span>
                        </div>
                        {submission.status === "winner" && (
                          <div className="ml-4 flex items-center text-amber-500">
                            <Trophy className="mr-1 h-4 w-4" />
                            <span>Winner</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Link href={`/challenges/${submission.challenge_id}`} className="w-full">
                        <Button variant="outline" className="w-full">
                          View Challenge
                        </Button>
                      </Link>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <MessageSquare className="mx-auto h-12 w-12 text-muted-foreground" />
                <h3 className="mt-4 text-lg font-medium">No submissions yet</h3>
                <p className="mt-2 text-muted-foreground">Browse challenges and submit your creative ideas.</p>
                <Link href="/challenges" className="mt-4 inline-block">
                  <Button>Browse Challenges</Button>
                </Link>
              </div>
            )}
          </TabsContent>
          <TabsContent value="achievements">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Total Submissions</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold">{mySubmissions.length}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Total Votes</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold">{mySubmissions.reduce((acc, sub) => acc + (sub.votes || 0), 0)}</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Winning Submissions</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold">{mySubmissions.filter((s) => s.status === "winner").length}</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}

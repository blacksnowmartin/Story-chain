"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/components/supabase-provider"

export default function NewChallenge() {
  const { user, supabase } = useSupabase()
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (!user) {
      toast({
        title: "Error",
        description: "You must be signed in to create a challenge",
        variant: "destructive",
      })
      router.push("/signin")
      return
    }

    setIsLoading(true)

    const formData = new FormData(e.currentTarget)
    const title = formData.get("title") as string
    const description = formData.get("description") as string

    try {
      const { data, error } = await supabase
        .from("challenges")
        .insert([
          {
            title,
            description,
            user_id: user.id,
            status: "open",
          },
        ])
        .select()

      if (error) throw error

      toast({
        title: "Challenge created!",
        description: "Your challenge has been posted successfully.",
      })

      router.push(`/challenges/${data[0].id}`)
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Create a New Challenge</h1>
        <p className="text-muted-foreground">Share your creative block and get ideas from the community</p>
      </div>

      <Card>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Challenge Title</Label>
              <Input id="title" name="title" placeholder="E.g., 'Need lyrics for the bridge of my song'" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                name="description"
                placeholder="Describe your creative block, provide context, and what kind of ideas you're looking for..."
                rows={6}
                required
              />
              <p className="text-sm text-muted-foreground">
                Be specific about what you need help with. Include relevant details like genre, mood, themes, etc.
              </p>
            </div>

            <div className="flex justify-end gap-4">
              <Button type="button" variant="outline" onClick={() => router.back()} disabled={isLoading}>
                Cancel
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? "Creating..." : "Create Challenge"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useSupabase } from "@/components/supabase-provider"
import { Search, MessageSquare, Clock } from "lucide-react"

type Challenge = {
  id: string
  title: string
  description: string
  created_at: string
  user_id: string
  status: string
  submission_count: number
  creator_name: string
}

export default function Challenges() {
  const { supabase } = useSupabase()
  const [challenges, setChallenges] = useState<Challenge[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  useEffect(() => {
    const fetchChallenges = async () => {
      try {
        // Updated query to properly join challenges with profiles
        const { data, error } = await supabase
          .from("challenges")
          .select(`
            *,
            profiles:profiles(name)
          `)
          .order("created_at", { ascending: false })

        if (error) throw error

        // Format the data to match our Challenge type
        const formattedChallenges = data.map((challenge: any) => ({
          ...challenge,
          creator_name: challenge.profiles?.name || "Anonymous",
        }))

        setChallenges(formattedChallenges)
      } catch (error) {
        console.error("Error fetching challenges:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchChallenges()
  }, [supabase])

  const filteredChallenges = challenges.filter((challenge) => {
    const matchesSearch =
      challenge.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      challenge.description.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilter === "all" || challenge.status === statusFilter

    return matchesSearch && matchesStatus
  })

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 flex justify-center">
        <div className="text-center">Loading challenges...</div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Explore Challenges</h1>
          <p className="text-muted-foreground">Browse creative challenges and submit your ideas</p>
        </div>
        <Link href="/challenges/new">
          <Button>Create Challenge</Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search challenges..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Challenges</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filteredChallenges.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredChallenges.map((challenge) => (
            <Card key={challenge.id}>
              <CardHeader>
                <CardTitle>{challenge.title}</CardTitle>
                <CardDescription>
                  By {challenge.creator_name} • {new Date(challenge.created_at).toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="line-clamp-3">{challenge.description}</p>
                <div className="flex items-center justify-between mt-4 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <MessageSquare className="mr-1 h-4 w-4" />
                    <span>{challenge.submission_count || 0} submissions</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="mr-1 h-4 w-4" />
                    <span
                      className={`capitalize ${
                        challenge.status === "open"
                          ? "text-green-500"
                          : challenge.status === "closed"
                            ? "text-amber-500"
                            : "text-blue-500"
                      }`}
                    >
                      {challenge.status}
                    </span>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Link href={`/challenges/${challenge.id}`} className="w-full">
                  <Button variant="outline" className="w-full">
                    View Challenge
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium">No challenges found</h3>
          <p className="mt-2 text-muted-foreground">Try adjusting your search or filter criteria</p>
        </div>
      )}
    </div>
  )
}

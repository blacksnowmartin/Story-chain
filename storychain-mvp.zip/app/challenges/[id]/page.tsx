"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { useSupabase } from "@/components/supabase-provider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Heart, MessageSquare, Trophy, Clock } from "lucide-react"

type Challenge = {
  id: string
  title: string
  description: string
  created_at: string
  user_id: string
  status: string
  creator_name: string
}

type Submission = {
  id: string
  challenge_id: string
  user_id: string
  content: string
  created_at: string
  votes: number
  status: string
  user_name: string
}

export default function ChallengePage() {
  const params = useParams()
  const router = useRouter()
  const { user, supabase } = useSupabase()
  const { toast } = useToast()
  const [challenge, setChallenge] = useState<Challenge | null>(null)
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isVoting, setIsVoting] = useState(false)
  const [userVotes, setUserVotes] = useState<Record<string, boolean>>({})
  const [submissionContent, setSubmissionContent] = useState("")
  const [sortBy, setSortBy] = useState("newest")

  const challengeId = params.id as string

  useEffect(() => {
    const fetchChallenge = async () => {
      try {
        // Fetch challenge details with correct join syntax
        const { data: challengeData, error: challengeError } = await supabase
          .from("challenges")
          .select(`
            *,
            profiles:profiles(name)
          `)
          .eq("id", challengeId)
          .single()

        if (challengeError) throw challengeError

        setChallenge({
          ...challengeData,
          creator_name: challengeData.profiles?.name || "Anonymous",
        })

        // Fetch submissions with correct join syntax
        const { data: submissionsData, error: submissionsError } = await supabase
          .from("submissions")
          .select(`
            *,
            profiles:profiles(name)
          `)
          .eq("challenge_id", challengeId)

        if (submissionsError) throw submissionsError

        const formattedSubmissions = submissionsData.map((sub: any) => ({
          ...sub,
          user_name: sub.profiles?.name || "Anonymous",
        }))

        setSubmissions(formattedSubmissions)

        // If user is logged in, fetch their votes
        if (user) {
          const { data: votesData } = await supabase.from("votes").select("submission_id").eq("user_id", user.id)

          const votes: Record<string, boolean> = {}
          votesData?.forEach((vote: any) => {
            votes[vote.submission_id] = true
          })
          setUserVotes(votes)
        }
      } catch (error) {
        console.error("Error fetching challenge:", error)
        toast({
          title: "Error",
          description: "Failed to load challenge",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchChallenge()
  }, [challengeId, supabase, toast, user])

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (!user) {
      toast({
        title: "Sign in required",
        description: "You must be signed in to submit an idea",
      })
      router.push("/signin")
      return
    }

    if (challenge?.status !== "open") {
      toast({
        title: "Challenge closed",
        description: "This challenge is no longer accepting submissions",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const { data, error } = await supabase
        .from("submissions")
        .insert([
          {
            challenge_id: challengeId,
            user_id: user.id,
            content: submissionContent,
          },
        ])
        .select()

      if (error) throw error

      // Update submission count in the challenge
      await supabase
        .from("challenges")
        .update({ submission_count: (challenge?.submission_count || 0) + 1 })
        .eq("id", challengeId)

      toast({
        title: "Submission successful!",
        description: "Your idea has been submitted.",
      })

      // Add the new submission to the list
      const { data: userData } = await supabase.from("profiles").select("name").eq("id", user.id).single()

      const newSubmission = {
        ...data[0],
        user_name: userData?.name || "Anonymous",
        votes: 0,
      }

      setSubmissions([newSubmission, ...submissions])
      setSubmissionContent("")
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to submit your idea",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleVote = async (submissionId: string) => {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "You must be signed in to vote",
      })
      router.push("/signin")
      return
    }

    setIsVoting(true)

    try {
      if (userVotes[submissionId]) {
        // Remove vote
        await supabase.from("votes").delete().eq("user_id", user.id).eq("submission_id", submissionId)

        // Update submission votes count
        const updatedSubmission = submissions.find((s) => s.id === submissionId)
        if (updatedSubmission) {
          await supabase
            .from("submissions")
            .update({ votes: (updatedSubmission.votes || 1) - 1 })
            .eq("id", submissionId)
        }

        // Update local state
        setUserVotes({ ...userVotes, [submissionId]: false })
        setSubmissions(submissions.map((s) => (s.id === submissionId ? { ...s, votes: (s.votes || 1) - 1 } : s)))
      } else {
        // Add vote
        await supabase.from("votes").insert([
          {
            user_id: user.id,
            submission_id: submissionId,
          },
        ])

        // Update submission votes count
        const updatedSubmission = submissions.find((s) => s.id === submissionId)
        if (updatedSubmission) {
          await supabase
            .from("submissions")
            .update({ votes: (updatedSubmission.votes || 0) + 1 })
            .eq("id", submissionId)
        }

        // Update local state
        setUserVotes({ ...userVotes, [submissionId]: true })
        setSubmissions(submissions.map((s) => (s.id === submissionId ? { ...s, votes: (s.votes || 0) + 1 } : s)))
      }
    } catch (error) {
      console.error("Error voting:", error)
      toast({
        title: "Error",
        description: "Failed to register your vote",
        variant: "destructive",
      })
    } finally {
      setIsVoting(false)
    }
  }

  const selectWinner = async (submissionId: string) => {
    if (!user || user.id !== challenge?.user_id) {
      toast({
        title: "Unauthorized",
        description: "Only the challenge creator can select a winner",
        variant: "destructive",
      })
      return
    }

    try {
      // Update submission status
      await supabase.from("submissions").update({ status: "winner" }).eq("id", submissionId)

      // Update challenge status
      await supabase.from("challenges").update({ status: "completed" }).eq("id", challengeId)

      // Update local state
      setChallenge(challenge ? { ...challenge, status: "completed" } : null)
      setSubmissions(submissions.map((s) => (s.id === submissionId ? { ...s, status: "winner" } : s)))

      toast({
        title: "Winner selected!",
        description: "You have successfully selected a winning submission.",
      })
    } catch (error) {
      console.error("Error selecting winner:", error)
      toast({
        title: "Error",
        description: "Failed to select winner",
        variant: "destructive",
      })
    }
  }

  const sortedSubmissions = [...submissions].sort((a, b) => {
    if (sortBy === "newest") {
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    } else if (sortBy === "popular") {
      return (b.votes || 0) - (a.votes || 0)
    }
    return 0
  })

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 flex justify-center">
        <div className="text-center">Loading challenge...</div>
      </div>
    )
  }

  if (!challenge) {
    return (
      <div className="container mx-auto px-4 py-8 flex justify-center">
        <div className="text-center">Challenge not found</div>
      </div>
    )
  }

  const isCreator = user?.id === challenge.user_id
  const hasSubmitted = submissions.some((s) => s.user_id === user?.id)
  const canSubmit = challenge.status === "open" && user && !hasSubmitted && !isCreator

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="mb-8">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-2xl">{challenge.title}</CardTitle>
              <CardDescription>
                By {challenge.creator_name} • {new Date(challenge.created_at).toLocaleDateString()}
              </CardDescription>
            </div>
            <div className="flex items-center">
              <Clock className="mr-1 h-4 w-4" />
              <span
                className={`capitalize ${
                  challenge.status === "open"
                    ? "text-green-500"
                    : challenge.status === "closed"
                      ? "text-amber-500"
                      : "text-blue-500"
                }`}
              >
                {challenge.status}
              </span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="whitespace-pre-wrap">{challenge.description}</p>
        </CardContent>
      </Card>

      {canSubmit && (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Submit Your Idea</CardTitle>
            <CardDescription>Share your creative solution to this challenge</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Textarea
                placeholder="Write your submission here (max 500 words)..."
                value={submissionContent}
                onChange={(e) => setSubmissionContent(e.target.value)}
                rows={6}
                required
                maxLength={2500}
              />
              <div className="flex justify-between items-center">
                <p className="text-sm text-muted-foreground">
                  {submissionContent.split(/\s+/).filter(Boolean).length}/500 words
                </p>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? "Submitting..." : "Submit Idea"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-2xl font-bold">Submissions ({submissions.length})</h2>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-muted-foreground">Sort by:</span>
          <Tabs value={sortBy} onValueChange={setSortBy} className="w-[200px]">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="newest">Newest</TabsTrigger>
              <TabsTrigger value="popular">Popular</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {sortedSubmissions.length > 0 ? (
        <div className="space-y-6">
          {sortedSubmissions.map((submission) => (
            <Card key={submission.id} className={submission.status === "winner" ? "border-amber-500" : ""}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{submission.user_name}</CardTitle>
                    <CardDescription>{new Date(submission.created_at).toLocaleDateString()}</CardDescription>
                  </div>
                  {submission.status === "winner" && (
                    <div className="flex items-center text-amber-500">
                      <Trophy className="mr-1 h-5 w-5" />
                      <span className="font-medium">Winner</span>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-wrap">{submission.content}</p>
                <div className="flex justify-between items-center mt-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    className={`flex items-center ${userVotes[submission.id] ? "text-primary" : ""}`}
                    onClick={() => handleVote(submission.id)}
                    disabled={isVoting || user?.id === submission.user_id}
                  >
                    {userVotes[submission.id] ? (
                      <Heart className="mr-1 h-4 w-4 fill-current" />
                    ) : (
                      <Heart className="mr-1 h-4 w-4" />
                    )}
                    <span>{submission.votes || 0} votes</span>
                  </Button>

                  {isCreator && challenge.status === "open" && (
                    <Button variant="outline" size="sm" onClick={() => selectWinner(submission.id)}>
                      <Trophy className="mr-1 h-4 w-4" />
                      Select as Winner
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <MessageSquare className="mx-auto h-12 w-12 text-muted-foreground" />
          <h3 className="mt-4 text-lg font-medium">No submissions yet</h3>
          <p className="mt-2 text-muted-foreground">Be the first to submit your creative idea!</p>
        </div>
      )}
    </div>
  )
}

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { BookOpen, Sparkles, Users, Trophy, ArrowRight } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)]">
      {/* Hero Section */}
      <section className="py-12 md:py-24 lg:py-32 bg-gradient-to-b from-background to-muted">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                Collaborative Storytelling for Creative Minds
              </h1>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Overcome creative blocks by crowdsourcing ideas from fans and fellow creators.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/challenges">
                <Button size="lg">
                  Explore Challenges
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/signup">
                <Button variant="outline" size="lg">
                  Start Creating
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-12 md:py-24 bg-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">How StoryChain Works</h2>
            <p className="mx-auto max-w-[700px] text-muted-foreground">
              A simple process to unlock creativity and collaboration
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="p-4 bg-primary/10 rounded-full">
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Post a Challenge</h3>
              <p className="text-muted-foreground">
                Share your creative block or scenario and provide context with images or audio.
              </p>
            </div>
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="p-4 bg-primary/10 rounded-full">
                <Sparkles className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Collect Ideas</h3>
              <p className="text-muted-foreground">
                Contributors submit their creative solutions and the community votes on favorites.
              </p>
            </div>
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="p-4 bg-primary/10 rounded-full">
                <Trophy className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Reward Winners</h3>
              <p className="text-muted-foreground">
                Select winning submissions and recognize contributors for their creativity.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* User Types */}
      <section className="py-12 md:py-24 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Who Uses StoryChain?</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-card rounded-lg p-6 shadow-sm">
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <Users className="mr-2 h-5 w-5" /> Creators
              </h3>
              <p className="text-muted-foreground mb-4">
                Musicians, directors, writers, and producers who need fresh ideas to overcome creative blocks.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <ArrowRight className="mr-2 h-4 w-4 mt-1 text-primary" />
                  <span>Post challenges with context and media</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="mr-2 h-4 w-4 mt-1 text-primary" />
                  <span>Review and select winning submissions</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="mr-2 h-4 w-4 mt-1 text-primary" />
                  <span>Reward contributors for their creativity</span>
                </li>
              </ul>
            </div>
            <div className="bg-card rounded-lg p-6 shadow-sm">
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <Users className="mr-2 h-5 w-5" /> Contributors
              </h3>
              <p className="text-muted-foreground mb-4">
                Fans, aspiring writers, and creative minds who want to participate in the creative process.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <ArrowRight className="mr-2 h-4 w-4 mt-1 text-primary" />
                  <span>Submit creative solutions to challenges</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="mr-2 h-4 w-4 mt-1 text-primary" />
                  <span>Vote on other submissions</span>
                </li>
                <li className="flex items-start">
                  <ArrowRight className="mr-2 h-4 w-4 mt-1 text-primary" />
                  <span>Earn recognition and rewards for winning ideas</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-24 bg-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Ready to Join the Creative Community?</h2>
            <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
              Sign up today and start collaborating on creative challenges.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/signup">
                <Button size="lg">Create an Account</Button>
              </Link>
              <Link href="/challenges">
                <Button variant="outline" size="lg">
                  Browse Challenges
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
